﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShooterScript : MonoBehaviour
{
    public KeyCode moveLeft = KeyCode.D;
    public KeyCode moveRight = KeyCode.A;
    public float shooterSpeed = 4.0f;
    public float xBound = 9.0f;
    private Rigidbody2D rb2d;
    // Start is called before the first frame update
    void Start()
    {
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
        var vel = rb2d.velocity;
        if(Input.GetKey(moveLeft))
        {
            vel.x = shooterSpeed;
        }
        else if(Input.GetKey(moveRight))
        {
            vel.x = -shooterSpeed;
        }
        rb2d.velocity = vel;

        var pos = transform.position;
        if (pos.x > xBound)
        {
            pos.x = xBound;
        }
        else if(pos.x < -xBound)
        {
            pos.x = -xBound;
        }
        transform.position = pos;
    }
}
