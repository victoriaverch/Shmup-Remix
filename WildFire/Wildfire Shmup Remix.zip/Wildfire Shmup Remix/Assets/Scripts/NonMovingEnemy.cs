﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NonMovingEnemy : MonoBehaviour
{
    public int health = 100;
    public GameObject exstinguish;
    Rigidbody2D rb;
    public float moveSpeed = 0.5f;
    public GameObject[] enemy;
    // Start is called before the first frame update
    void Start()

    {
        rb = GetComponent<Rigidbody2D>();
        moveSpeed = Random.Range(1f, 3f);
    }

    // Update is called once per frame
    

    public void TakeDamage(int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Die();
        }
    }

    void Die()
    {
        Instantiate(exstinguish, transform.position, Quaternion.identity);
        Destroy(gameObject);
    }
}
