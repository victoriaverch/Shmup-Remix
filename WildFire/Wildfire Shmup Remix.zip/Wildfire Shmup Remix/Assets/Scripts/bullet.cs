﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour
{
    public float speed = 10f;
    public Rigidbody2D rb;
    public int damage = 40;
    public GameObject impactEffect;
    // Start is called before the first frame update
    void Start()
    {
        rb.velocity = transform.right * speed;
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        enemy fireEnemy = collision.GetComponent<enemy>();
        NonMovingEnemy burnEnemy = collision.GetComponent<NonMovingEnemy>();
        EmberEnemy emberEnemy = collision.GetComponent<EmberEnemy>();
        Debug.Log(collision);
        if(fireEnemy != null)
        {
            fireEnemy.TakeDamage(damage);
        }
        else if (burnEnemy != null)
        {
            burnEnemy.TakeDamage(damage);
        }
        else if (emberEnemy != null)
        {
            emberEnemy.TakeDamage(damage);
        }

        Instantiate(impactEffect, transform.position, transform.rotation);
        Destroy(gameObject);
    }
}

    
