﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawnControl : MonoBehaviour
{
    public Transform[] spawnPoints;
    public GameObject[] enemy;
    int randomSpawnPoint, randomEnemy;
    public static bool spawnAllowed;
    private float timeDelay = 1.75f;
    private float increment = 0.01f;
    private float spawnTime = 0f;

    // Start is called before the first frame update
    void Start()
    {
        
        StartCoroutine(SpawnAEnemy());

    }

    void Update()
    {
        spawnTime += Time.fixedTime;// fixedTime or deltaTime?
    }

    // Update is called once per frame
    IEnumerator SpawnAEnemy()
    {
        
       while(true)
        {
            randomSpawnPoint = Random.Range(0, spawnPoints.Length);
            randomEnemy = Random.Range (0, enemy.Length);
            Instantiate(enemy[randomEnemy], spawnPoints[randomSpawnPoint].position, Quaternion.identity);
            yield return new WaitForSeconds(timeDelay);
            timeDelay -= increment;
        } 
    }
}
