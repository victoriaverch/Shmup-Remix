﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EmberSpawnControl : MonoBehaviour
{
    public Transform[] spawnPoints;
    public GameObject[] enemy;
    int randomSpawnPoint, randomEnemy;
    public static bool spawnAllowed;
    private float timeDelay = 1.75f;
    private float increment = 0.01f;
    private float spawnTime = 0f;
    

    void Start()
    { 
        StartCoroutine(SpawnFire());
    }
    // Update is called once per frame
    void Update()
    {
        spawnTime += Time.fixedTime;
    }

    IEnumerator SpawnFire()
    {
        randomSpawnPoint = Random.Range(0, spawnPoints.Length);
        randomEnemy = Random.Range(0, enemy.Length);
        Instantiate(enemy[randomEnemy], spawnPoints[randomSpawnPoint].position, Quaternion.identity);
        yield return new WaitForSeconds(timeDelay);
        timeDelay -= increment;
    }

    
    //Spawner
    //void SpawnEnemy()
    //{

    //    if (spawnAllowed)
    //    {
    //        randomSpawnPoint = Random.Range(0, spawnPoints.Length);
    //        randomEnemy = Random.Range(0, enemy.Length);
    //        Instantiate(enemy[randomEnemy], spawnPoints[randomSpawnPoint].position, Quaternion.identity);
    //    }
    //}
}
