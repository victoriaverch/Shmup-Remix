﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WaveSpawner : MonoBehaviour
{

    public enum SpawnState
    {
        SPAWNING,
        WAITING,
        COUNTING
    }

    [System.Serializable]
    public class Waves
    {
        public string name;
        public Transform enemy;
        public int count;
        public float spawnRate;
        public Transform lava;
        public int lavaPools;

    }

    public Transform[] spawnPoints;
    
    public Transform[] lavaSpawn;

    
    public Waves[] waves;
    private int nextWave = 0;
    public float timeBetween = 5f;
    public float countdown;
    //private float watchCountdown = 1f;
    

    public SpawnState spawnState = SpawnState.COUNTING;

    void Start()
    {
        countdown = timeBetween;
    }

    void Update()
    {
        if(spawnState == SpawnState.WAITING)
        {
            //check if enemies
            if(!EnemiesAlive())
            {
                //new wave
                Debug.Log("Wave Complete");
                WaveCompleted();
          
            }
            else
            {
                return;
            }
            
        }
        if(countdown <= 0)
        {
            if(spawnState != SpawnState.SPAWNING)
            {
                StartCoroutine(WaveSpawn(waves[nextWave]));
            }
        }
        else
        {
            countdown -= Time.deltaTime;
        }

    }

    public void WaveCompleted()
    {
        
        spawnState = SpawnState.COUNTING;
        countdown = timeBetween;

        if(nextWave+1 > waves.Length - 1)
        {
            Restart();
            Debug.Log("Complete!");
        }
        else
        {
            //KillLava();
            Debug.Log("Next Wave");
            nextWave++;
        
           
        }
        
    }

    public bool EnemiesAlive()
    {
        GameObject[] enemies = GameObject.FindGameObjectsWithTag("Enemy");
        

       if (GameObject.FindGameObjectsWithTag("Enemy").Length == 0)
       {
          Debug.Log("All Enemies Gone");
  
          return false;    
       }
       else
       {
           return true;
       }
       
    }

    IEnumerator WaveSpawn (Waves wave)
    {
       
        spawnState = SpawnState.SPAWNING;

        
        Debug.Log("Spawning" + wave.name);

        

        for(int i = 0; i < wave.count; i++)
        {
            SpawnEnemy(wave.enemy);
            yield return new WaitForSeconds(1f/wave.spawnRate);
        }
        SpawnLava(wave.lava);

        //waiting for player to finish killing enemies
        spawnState = SpawnState.WAITING;
        Debug.Log("Waiting");

        yield break;
    }

    void SpawnEnemy (Transform enemy)
    {
        Transform sp = spawnPoints[Random.Range(0, spawnPoints.Length)];
        Instantiate(enemy, sp.position, sp.rotation);

    }
    

    void SpawnLava(Transform lava)
    {
       
        Transform la = lavaSpawn[Random.Range(0, lavaSpawn.Length)];
        Instantiate(lava, la.position, Quaternion.identity);
        Debug.Log("LAVAPOOLS");
    }

    void KillLava()
    {
        GameObject[] lavaPool = GameObject.FindGameObjectsWithTag("Lava");
        for (int i = 0; i < lavaPool.Length; i++)
        {
            Debug.Log("removing lava");
            Destroy(gameObject);
        }
    }

    void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }






}
