﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LavaControl : MonoBehaviour
{
    public int damage = 10;

    public void OnTriggerEnter2D(Collider2D collision)
    {
        PlayerControl player = collision.GetComponent<PlayerControl>();

        if (player != null)
        {
            Debug.Log("Damage");
            player.TakeDamage(damage);
            
        }
    }

    public void TakeDamage(int damage)
    {
        PlayerControl.currentHealth -= damage;
        if (PlayerControl.currentHealth <= 0)
        {
           Die();
        }
    }

    public void Die()
    {
        Destroy(gameObject);
    }

}
