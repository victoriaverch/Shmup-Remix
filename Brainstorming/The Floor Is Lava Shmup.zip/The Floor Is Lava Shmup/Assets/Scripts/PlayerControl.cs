﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerControl : MonoBehaviour
{
    public KeyCode moveLeft = KeyCode.D;
    public KeyCode moveRight = KeyCode.A;
    public KeyCode moveUp = KeyCode.W;
    public KeyCode moveDown = KeyCode.S;
    public float xBound = 15.0f;
    public float yBound = 6.5f;
    public float shooterSpeed =1.50f;
    public Rigidbody2D rb;
    public int health = 100;
    public static int currentHealth;

    public HealthBar healthBar;
 
    // Start is called before the first frame update
    void Start()
    {
        currentHealth = health;
        healthBar.SetHealth(health);
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        
        var vel = rb.velocity;
        if (Input.GetKeyDown(moveLeft))
        {
            vel.x = shooterSpeed;
            
           
        }
        else if (Input.GetKeyDown(moveRight))
        {
            vel.x = -shooterSpeed;
            
        }
        else if (Input.GetKeyDown(moveDown))
        {
            vel.y = -shooterSpeed;
            
        }
        else if (Input.GetKeyDown(moveUp))
        {
            vel.y = shooterSpeed;
            
        }
      
        rb.velocity = vel;

    

        var pos = transform.position;
        if (pos.x > xBound)
        {
            pos.x = xBound;
        }
        else if (pos.x < -xBound)
        {
            pos.x = -xBound;
        }
        else if (pos.y > yBound)
        {
            pos.y = yBound;
        }
        else if (pos.y < -yBound)
        {
            pos.y = -yBound;
        }
        transform.position = pos;
    }


    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        Debug.Log(currentHealth);

        healthBar.SetHealth(currentHealth);

        if (currentHealth <= 0)
        {
            Debug.Log(currentHealth);
            Invoke("Restart", 1f);
        }
    }

    

    void Restart()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
