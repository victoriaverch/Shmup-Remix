﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyControl : MonoBehaviour
{
    public int health = 80;
    public int damage = 25;
    public float moveSpeed = 5.0f;
    public GameObject target;
    public GameObject destroy;
    Rigidbody2D rb2d;
    Vector3 directionToTarget;
    // Start is called before the first frame update
    void Start()
    {
        target = GameObject.Find("Player");
        rb2d = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        MoveEnemy();
    }

    void MoveEnemy ()
    {
        if (target != null)
        {
            //guided Enemy towards shooter
            directionToTarget = (target.transform.position - transform.position).normalized;
            rb2d.velocity = new Vector2(directionToTarget.x * moveSpeed, directionToTarget.y * moveSpeed);
        }
        else
        {
            rb2d.velocity = Vector3.zero;
        }
    }

    public void TakeDamage (int damage)
    {
        health -= damage;
        Debug.Log(health + ":" + damage);

        if(health <= 0)
        {
            Debug.Log("Has Died");
            Die();
        }
    }

    public void Die ()
    {
        Destroy(gameObject);
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        PlayerControl player = collision.GetComponent<PlayerControl>();

        if(player != null)
        {
            player.TakeDamage(damage);
            Debug.Log("Damage");
            Destroy(gameObject);
        }

        
           
    }
}

