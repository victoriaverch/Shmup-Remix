﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;

public class AimWeapon : MonoBehaviour
{
    private Transform aimTransform;
    public Transform firePoint;
    public GameObject bullet;
    public GameObject crosshair;
    public GameObject player;
    public float speed = 50.0f;
    private float a;

    void Start()
    {
        Cursor.visible = false;
    }

    //Gets the position of the mouse using the main camera
    public static Vector3 GetMouseWorldPosition()
    {
        Vector3 vec = GetMouseWorldPositionWithZ(Input.mousePosition, Camera.main);
        vec.z = 0f;
        return vec;
    }
    public static Vector3 GetMouseWorldPositionWithZ()
    {
        return GetMouseWorldPositionWithZ(Input.mousePosition, Camera.main);
    }
    public static Vector3 GetMouseWorldPositionWithZ(Camera worldCamera)
    {
        return GetMouseWorldPositionWithZ(Input.mousePosition, worldCamera);
    }
    public static Vector3 GetMouseWorldPositionWithZ(Vector3 screenPosition, Camera worldCamera)
    {
        Vector3 worldPosition = worldCamera.ScreenToWorldPoint(screenPosition);
        return worldPosition;
    }

    private void Awake()
    {
        aimTransform = transform.Find("Aim");
    }

    void Update()
    {
        Vector3 mouseAim = GetMouseWorldPosition();
        crosshair.transform.position = new Vector2(mouseAim.x, mouseAim.y);
        Vector3 mouseDistance = mouseAim - player.transform.position;
        float angle = Mathf.Atan2(mouseDistance.y, mouseDistance.x) * Mathf.Rad2Deg;
        player.transform.rotation = Quaternion.Euler(0.0f, 0.0f, angle);

        if(Input.GetMouseButtonDown(0))
        {
            float distance = mouseDistance.magnitude;
            Vector2 direction = mouseDistance / distance;
            direction.Normalize();
            Shooting(direction, angle);
        }
    }


    void Shooting(Vector2 direction,float angle)
    {
       
          Debug.Log("shooting");
        Instantiate(bullet, firePoint.position, firePoint.rotation);
          //GameObject b = Instantiate(bullet);
          //b.transform.position = player.transform.position;
          //b.transform.rotation = Quaternion.Euler(0.0f, 0.0f, angle);
          //b.GetComponent<Rigidbody2D>().velocity = direction * speed;

    }



    
}
