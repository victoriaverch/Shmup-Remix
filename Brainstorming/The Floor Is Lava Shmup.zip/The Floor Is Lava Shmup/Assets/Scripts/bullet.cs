﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour
{
    public float speed = 10f;
    public Rigidbody2D rb;
    public int damage = 40;
    public static int score;
    
    private float timer;
    // Start is called before the first frame update
    void Start()
    {
       
            rb.velocity = transform.right * speed;
      
       
    }

    void Update()
    {
        timer = +1.0f * Time.deltaTime;
        if(timer >= 4)
        {
            Destroy(gameObject);
        }
    }
    public void OnTriggerEnter2D(Collider2D collision)
    {
        EnemyControl fireball = collision.GetComponent<EnemyControl>();
        EnemyControl flame = collision.GetComponent<EnemyControl>();
        EnemyControl lavaball = collision.GetComponent<EnemyControl>();
        Debug.Log(collision);

        if (fireball != null)
        {
            fireball.TakeDamage(damage);
            score++;
           

        }
        else if (flame != null)
        {
            flame.TakeDamage(damage);
            score++;
           
        }
        else if (lavaball != null)
        {
            lavaball.TakeDamage(damage);
            score++;
            
        }
        Destroy(gameObject);

        
       
            
    }



}
